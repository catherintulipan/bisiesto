﻿Public Class Form2
    Dim añoBisiesto As Integer
    Function Calcular(añoBisiesto As Integer) As Boolean
        Dim AB As Boolean
        If (añoBisiesto Mod 4 = 0 Or añoBisiesto Mod 100 = 0 Or añoBisiesto Mod 400 = 0) Then
            AB = True
        Else
            AB = False
        End If
        Return AB
    End Function


    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim nombre As String
        nombre = Form1.txtNombre.Text
        LbBienvenido.Text = ("Bienvenido " + nombre)
    End Sub

    Private Sub BtnAceptar_Click(sender As Object, e As EventArgs) Handles BtnAceptar.Click
        Dim añoBisiesto As Integer = Val(txtAño.Text)
        Dim Bisiesto As String
        Dim TF As Boolean

        TF = Calcular(añoBisiesto)

        If TF = True Then
            Bisiesto = "Es bisiesto"
        Else
            Bisiesto = "No es bisiesto"
        End If

        Label3.Text = Bisiesto
        Label5.Text = ("Gracias por usar mi programa")
        Label4.Text = ("Mi nombre es Catherin")
        Label6.Text = ("Soy alumna de 3º EMT de la Escuela 
  Técnica María Espínola Espínola")


    End Sub
End Class